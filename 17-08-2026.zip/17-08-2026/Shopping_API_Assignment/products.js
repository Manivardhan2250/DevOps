let products=[
    {
        id:1,
        name: "Product 1",
        price: 10.99,
        description: "This is product 1",
        category: "Electronics"
    },
    {
        id:2,
        name: "Product 2",
        price: 19.99,
        description: "This is product 2",
        category: "Home Appliances"
    },
    {
        id:3,
        name: "Product 3",
        price: 5.99,
        description: "This is product 3",
        category: "Clothing"
    }
];