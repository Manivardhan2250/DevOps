const { Sequelize } = require("sequelize");

const sequelize = new Sequelize(
    "shopping_db",
    "postgres",
    "YOUR_POSTGRES_PASSWORD",
    {
        host: "localhost",
        dialect: "postgres",
        port: 5432,
        logging: false
    }
);

module.exports = sequelize;