const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const Product = sequelize.define(
    "Product",
    {
        productId: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },

        productName: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                notEmpty: {
                    msg: "Product name is required"
                }
            }
        },

        category: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                notEmpty: {
                    msg: "Category is required"
                }
            }
        },

        price: {
            type: DataTypes.DECIMAL(10, 2),
            allowNull: false,
            validate: {
                notNull: {
                    msg: "Price is required"
                },
                min: {
                    args: [0],
                    msg: "Price cannot be negative"
                }
            }
        },

        stockQuantity: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                notNull: {
                    msg: "Stock quantity is required"
                },
                min: {
                    args: [0],
                    msg: "Stock quantity cannot be negative"
                }
            }
        }
    },
    {
        tableName: "products",
        timestamps: true
    }
);

module.exports = Product;