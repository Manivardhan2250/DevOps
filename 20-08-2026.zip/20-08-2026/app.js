const express = require("express");
const sequelize = require("./config/database");

const productRoutes = require("./routes/productRoutes");

const app = express();

app.use(express.json());

app.get("/", (req, res) => {
    res.json({
        message: "Online Shopping Product API is running"
    });
});

app.use("/api/products", productRoutes);

// Connect database
sequelize
    .authenticate()
    .then(() => {
        console.log("PostgreSQL database connected successfully");

        return sequelize.sync();
    })
    .then(() => {
        console.log("Product table created/synchronized successfully");

        app.listen(3000, () => {
            console.log("Server running on http://localhost:3000");
        });
    })
    .catch((error) => {
        console.error("Database connection failed:", error.message);
    });