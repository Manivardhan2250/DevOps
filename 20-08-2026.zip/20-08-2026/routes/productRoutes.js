const express = require("express");

const router = express.Router();

const {
    createProduct,
    getProducts,
    getProductById,
    updateProductPrice,
    deleteProduct,
    getProductsByCategory,
    sortProductsByPrice
} = require("../controllers/productController");

router.post("/", createProduct);

router.get("/", getProducts);

router.get("/category/:category", getProductsByCategory);

router.get("/sort/price", sortProductsByPrice);

router.get("/:id", getProductById);

router.put("/:id/price", updateProductPrice);

router.delete("/:id", deleteProduct);

module.exports = router;