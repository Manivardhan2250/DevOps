
require("dotenv").config();

const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");

const app = express();

app.use(cors());
app.use(express.json());

const PORT = Number(process.env.PORT) || 5000;

const pool = new Pool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME || "shopping_db",
  user: process.env.DB_USER || "shopping_user",
  password: process.env.DB_PASSWORD,
  connectionTimeoutMillis: 5000
});

// Create the products table when PostgreSQL is available.
async function initializeDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS products (
      id SERIAL PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      price NUMERIC(12, 2) NOT NULL CHECK (price >= 0),
      category VARCHAR(100) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  // Seed the sample products only when the table is empty.
  await pool.query(`
    INSERT INTO products (id, name, price, category)
    SELECT v.id, v.name, v.price, v.category
    FROM (VALUES
      (1, 'Laptop', 60000, 'Electronics'),
      (2, 'Headphones', 2000, 'Electronics')
    ) AS v(id, name, price, category)
    WHERE NOT EXISTS (SELECT 1 FROM products)
    ON CONFLICT (id) DO NOTHING
  `);

  // Keep the generated ID sequence aligned with existing records.
  await pool.query(`
    SELECT setval(
      pg_get_serial_sequence('products', 'id'),
      COALESCE((SELECT MAX(id) FROM products), 1),
      EXISTS (SELECT 1 FROM products)
    )
  `);

  console.log("PostgreSQL database initialized.");
}

function validateProduct(body, partial = false) {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return "Request body must be a JSON object.";
  }

  const fields = ["name", "price", "category"];

  if (!partial && fields.some((field) => body[field] === undefined)) {
    return "name, price, and category are required.";
  }

  if (partial && !fields.some((field) => body[field] !== undefined)) {
    return "Provide at least one field to update.";
  }

  if (
    body.name !== undefined &&
    (typeof body.name !== "string" || !body.name.trim())
  ) {
    return "name must be a non-empty string.";
  }

  if (
    body.category !== undefined &&
    (typeof body.category !== "string" || !body.category.trim())
  ) {
    return "category must be a non-empty string.";
  }

  if (
    body.price !== undefined &&
    (body.price === null ||
      body.price === "" ||
      !Number.isFinite(Number(body.price)) ||
      Number(body.price) < 0)
  ) {
    return "price must be a non-negative number.";
  }

  return null;
}

function parseId(value) {
  if (!/^[1-9]\d*$/.test(value)) return null;

  const id = Number(value);
  return Number.isSafeInteger(id) ? id : null;
}

// Health check: returns 200 only when PostgreSQL is reachable.
app.get("/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.status(200).json({
      status: "healthy",
      database: "connected"
    });
  } catch (error) {
    res.status(503).json({
      status: "unhealthy",
      database: "disconnected"
    });
  }
});

// GET /api/products
app.get("/api/products", async (req, res, next) => {
  try {
    const result = await pool.query(
      "SELECT id, name, price, category, created_at FROM products ORDER BY id"
    );

    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

// GET /api/products/:id
app.get("/api/products/:id", async (req, res, next) => {
  const id = parseId(req.params.id);

  if (!id) {
    return res.status(400).json({ error: "Invalid product ID." });
  }

  try {
    const result = await pool.query(
      "SELECT id, name, price, category, created_at FROM products WHERE id = $1",
      [id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Product not found." });
    }

    res.json(result.rows[0]);
  } catch (error) {
    next(error);
  }
});

// POST /api/products
app.post("/api/products", async (req, res, next) => {
  const validationError = validateProduct(req.body);

  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  try {
    const { name, price, category } = req.body;

    const result = await pool.query(
      `INSERT INTO products (name, price, category)
       VALUES ($1, $2, $3)
       RETURNING id, name, price, category, created_at`,
      [name.trim(), Number(price), category.trim()]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    next(error);
  }
});

// PUT /api/products/:id
app.put("/api/products/:id", async (req, res, next) => {
  const id = parseId(req.params.id);

  if (!id) {
    return res.status(400).json({ error: "Invalid product ID." });
  }

  const validationError = validateProduct(req.body, true);

  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  try {
    const existing = await pool.query(
      "SELECT id FROM products WHERE id = $1",
      [id]
    );

    if (existing.rowCount === 0) {
      return res.status(404).json({ error: "Product not found." });
    }

    const { name, price, category } = req.body;
    const result = await pool.query(
      `UPDATE products
       SET name = COALESCE($1, name),
           price = COALESCE($2, price),
           category = COALESCE($3, category)
       WHERE id = $4
       RETURNING id, name, price, category, created_at`,
      [
        name === undefined ? null : name.trim(),
        price === undefined ? null : Number(price),
        category === undefined ? null : category.trim(),
        id
      ]
    );

    res.json(result.rows[0]);
  } catch (error) {
    next(error);
  }
});

// DELETE /api/products/:id
app.delete("/api/products/:id", async (req, res, next) => {
  const id = parseId(req.params.id);

  if (!id) {
    return res.status(400).json({ error: "Invalid product ID." });
  }

  try {
    const result = await pool.query(
      "DELETE FROM products WHERE id = $1 RETURNING id, name",
      [id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Product not found." });
    }

    res.json({
      message: "Product deleted successfully.",
      product: result.rows[0]
    });
  } catch (error) {
    next(error);
  }
});

// Handle invalid JSON and other request errors.
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && "body" in err) {
    return res.status(400).json({ error: "Invalid JSON body." });
  }

  console.error("Request error:", err.message);

  res.status(500).json({ error: "Internal server error." });
});

let server;

async function startServer() {
  try {
    await initializeDatabase();

    server = app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error("Failed to initialize application:", error.message);
    process.exitCode = 1;
  }
}

async function shutdown() {
  if (server) {
    await new Promise((resolve) => server.close(resolve));
  }

  await pool.end();
  process.exit(0);
}

process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);

startServer();
