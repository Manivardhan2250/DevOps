const express = require("express");
const dotenv = require("dotenv");

dotenv.config();

const app = express();

app.use(express.json());

// Authentication routes
const authRoutes = require("./routes/authRoutes");

// Student routes
const studentRoutes = require("./routes/studentRoutes");

app.use("/", authRoutes);
app.use("/", studentRoutes);

app.get("/", (req, res) => {
    res.json({
        message: "Student Portal API is running"
    });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});