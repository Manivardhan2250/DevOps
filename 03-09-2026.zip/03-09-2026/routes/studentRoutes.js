const express = require("express");

const authenticateToken =
    require("../middleware/authMiddleware");

const {
    getProfile
} = require("../controllers/studentController");

const router = express.Router();

router.get(
    "/profile",
    authenticateToken,
    getProfile
);

router.get(
    "/students",
    authenticateToken,
    getStudents
);

module.exports = router;