const getStudents = (req, res) => {

    const students = users
        .filter(user => user.role === "student")
        .map(user => ({
            id: user.id,
            name: user.name,
            email: user.email,
            department: user.department
        }));

    res.json({
        count: students.length,
        students
    });
};
module.exports = {
    getProfile,
    getStudents
};